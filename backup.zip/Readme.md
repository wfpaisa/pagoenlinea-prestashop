# Pago Estandar

## Instalar
Descargar y descomprimir en la carpeta de modulos, luego renombrar la carpeta raiz por -> 'pagoestandar'

